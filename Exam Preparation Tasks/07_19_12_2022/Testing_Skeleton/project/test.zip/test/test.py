from unittest import TestCase, main
from project.truck_driver import TruckDriver


class TestTruckDriver(TestCase):
    def setUp(self):
        self.driver = TruckDriver("Jo", 10)

    def test_init(self):
        self.assertEqual("Jo", self.driver.name)
        self.assertEqual(10, self.driver.money_per_mile)
        self.assertEqual({}, self.driver.available_cargos)
        self.assertEqual(0.0, self.driver.earned_money)
        self.assertEqual(0, self.driver.miles)

    def test_setter_earned_money_value_less_than_zero_raises_value_error(self):
        with self.assertRaises(ValueError) as ve:
            self.driver.earned_money = -1

        self.assertEqual("Jo went bankrupt.", str(ve.exception))

    def test_add_cargo_offer_location_in_available_cargos_raises_exception(self):
        self.driver.available_cargos = {"Cargo 1": 10}

        with self.assertRaises(Exception) as ex:
            self.driver.add_cargo_offer("Cargo 1", 10)

        self.assertEqual("Cargo offer is already added.", str(ex.exception))

    def test_add_cargo_offer_happy_case(self):
        res = self.driver.add_cargo_offer("Cargo 2", 5)
        expect = f"Cargo for 5 to Cargo 2 was added as an offer."

        self.assertEqual({"Cargo 2": 5}, self.driver.available_cargos)
        self.assertEqual(expect, res)

    def test_drive_best_cargo_offer_no_offers_available_raises_value_error(self):
        result = self.driver.drive_best_cargo_offer()
        self.assertEqual(result, "There are no offers available.")

    def test_drive_best_cargo_offer_happy_case(self):
        self.driver.available_cargos = {"Cargo 1": 10, "Cargo 2": 5, "Cargo 3": 2}

        expect_earned_money = 10 * self.driver.money_per_mile
        res = self.driver.drive_best_cargo_offer()
        expect = f"Jo is driving 10 to Cargo 1."

        self.assertEqual(expect, res)
        self.assertEqual(expect_earned_money, self.driver.earned_money)
        self.assertEqual(10, self.driver.miles)
        # TODO CHECK FOR ACTIVITIES

    def test_eat_every_250_miles_earned_money_decrease_with_20(self):
        self.driver.earned_money = 100

        self.driver.eat(250)
        self.driver.eat(500)

        self.assertEqual(60, self.driver.earned_money)

    def test_sleep_every_1000_miles_earned_money_decrease_with_45(self):
        self.driver.earned_money = 100

        self.driver.sleep(1000)
        self.driver.sleep(2000)

        self.assertEqual(10, self.driver.earned_money)

    def test_pump_gas_every_1500_miles_earned_money_decrease_with_500(self):
        self.driver.earned_money = 1500

        self.driver.pump_gas(1500)
        self.driver.pump_gas(3000)

        self.assertEqual(500, self.driver.earned_money)

    def test_repair_truck_every_10_000_miles_earned_money_decrease_with_7500(self):
        self.driver.earned_money = 16_000

        self.driver.repair_truck(10_000)
        self.driver.repair_truck(20_000)

        self.assertEqual(1000, self.driver.earned_money)

    def test__repr__(self):
        self.assertEqual("Jo has 0 miles behind his back.", self.driver.__repr__())


if __name__ == '__main__':
    main()
