from project.mammal import Mammal


class Gorilla(Mammal):
    pass
